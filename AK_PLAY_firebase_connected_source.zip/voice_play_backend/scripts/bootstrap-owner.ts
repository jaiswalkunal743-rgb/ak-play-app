/**
 * Run only from a trusted machine with Firebase Admin SDK Application Default Credentials.
 * Configure OWNER_PHONE_E164 in this script before use. Never commit credentials.
 * Usage after compiling: node lib/bootstrap-owner.js <firebase-auth-uid>
 */
import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

initializeApp();
const OWNER_PHONE_E164 = process.env.OWNER_PHONE_E164; // set securely, e.g. +91XXXXXXXXXX
async function main() {
  const uid = process.argv[2];
  if (!OWNER_PHONE_E164 || !uid) throw new Error("Set OWNER_PHONE_E164 and pass the authenticated owner UID.");
  const auth = getAuth();
  const user = await auth.getUser(uid);
  if (user.phoneNumber !== OWNER_PHONE_E164) throw new Error("UID phone number does not match configured owner allowlist.");
  await auth.setCustomUserClaims(uid, { ...(user.customClaims ?? {}), role: "owner" });
  await getFirestore().doc(`users/${uid}`).set({
    role:"owner", status:"approved", ownerProvisionedAt:FieldValue.serverTimestamp()
  }, { merge:true });
  console.log("Owner role provisioned. User must refresh ID token / sign in again.");
}
main().catch((e) => { console.error(e); process.exit(1); });
