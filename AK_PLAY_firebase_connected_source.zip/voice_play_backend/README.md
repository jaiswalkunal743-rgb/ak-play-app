# Voice Play — Firebase Backend Starter

This is a secure backend starter for the Voice Play Flutter app.

## Stack
- Firebase Authentication (phone OTP)
- Cloud Firestore
- Cloud Functions for Firebase (2nd gen, TypeScript)
- Firebase App Check (recommended before production)
- Firebase Analytics, Crashlytics and Performance Monitoring in Flutter

## Important setup
1. Install Node.js 20+, Firebase CLI and FlutterFire CLI.
2. In Firebase Console, enable Phone Authentication and create a Firestore database.
3. From this folder run `npm install` inside `functions/`.
4. Run `firebase login`, then `firebase use --add` and select your **Voice play** Firebase project.
5. Deploy rules and functions with `firebase deploy --only firestore:rules,firestore:indexes,functions`.
6. Configure the owner phone in Functions config/secrets as described below, then securely bootstrap the Owner role.

This folder is backend source code; it does not create or deploy a Firebase project by itself.

## Owner account security
The owner phone number is treated as an identity allowlist hint, not as sufficient proof to grant Super Admin.
A verified phone number alone must not let a client assign roles. The first Super Admin must be provisioned by a trusted operator using the Admin SDK from a secure environment. Do not put service-account JSON in the app or commit it to source control.

Set the owner phone in E.164 format using the secret/configuration value `OWNER_PHONE_E164` (example: `+91XXXXXXXXXX`). Do not place the phone number in client code. After the owner signs in with Firebase Phone Auth, a trusted operator runs the one-time bootstrap script in `scripts/bootstrap-owner.ts` using Application Default Credentials. The script checks the configured phone and grants the custom claims. Review and replace the placeholder before running.

## Collections
- `users/{uid}`: profile, approval state and role
- `wallets/{uid}`: server-managed balance
- `walletTransactions/{transactionId}`: immutable ledger entries
- `gifts/{giftId}`: gift catalogue
- `rooms/{roomId}`: room metadata and moderation state
- `roomMembers/{roomId_uid}`: room membership
- `vipPlans/{planId}`: VIP catalogue
- `adminAuditLogs/{logId}`: administrative audit trail
- `appMetricsDaily/{yyyy-mm-dd}`: aggregated operational counters

## Current scope / production integrations still required
- Voice transport (Agora, LiveKit or another provider): this backend stores room metadata and authorization; it does not stream audio.
- Store billing: implement and test Google Play Billing / Apple StoreKit receipt or purchase-token verification before crediting coins or VIP. Never trust a client-sent “payment successful” flag.
- Gift animation: Flutter clients subscribe to room gift events and render the animation for all room members.
- Analytics: add Firebase Analytics, Crashlytics and Performance Monitoring Flutter SDKs. Avoid logging phone numbers, OTPs, payment credentials or private messages.
- Monitoring alerts: configure Firebase/Google Cloud alerting for function errors, latency, Firestore usage and billing budgets.
- UPI: a UPI ID by itself is not a payment-verification integration. For digital goods, follow the applicable Google Play and Apple App Store billing rules.

## Test before launch
Use the Firebase Emulator Suite, add automated tests for role escalation, wallet tampering, duplicate payment callbacks, approval flows and room access. Obtain a security review before production.
