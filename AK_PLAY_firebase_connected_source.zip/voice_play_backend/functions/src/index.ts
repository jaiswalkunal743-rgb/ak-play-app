import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { FieldValue, getFirestore } from "firebase-admin/firestore";
import { HttpsError, onCall } from "firebase-functions/v2/https";
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { logger } from "firebase-functions";

initializeApp();
const db = getFirestore();

type Role = "user" | "moderator" | "admin" | "owner";
function requireAuth(request: any) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in required.");
  return request.auth;
}
function requireModerator(request: any) {
  const auth = requireAuth(request);
  if (!["owner", "admin", "moderator"].includes(auth.token.role)) {
    throw new HttpsError("permission-denied", "Moderator permission required.");
  }
  return auth;
}
function requireAdmin(request: any) {
  const auth = requireAuth(request);
  if (!["owner", "admin"].includes(auth.token.role)) {
    throw new HttpsError("permission-denied", "Admin permission required.");
  }
  return auth;
}
function requireOwner(request: any) {
  const auth = requireAuth(request);
  if (auth.token.role !== "owner") throw new HttpsError("permission-denied", "Owner only.");
  return auth;
}

// New accounts are pending. No client can self-approve or choose a role.
export const initializeUser = onDocumentCreated("users/{uid}", async (event) => {
  const uid = event.params.uid;
  const user = event.data?.data();
  if (!user) return;
  await db.doc(`users/${uid}`).set({
    status: "pending", role: "user", createdAt: user.createdAt ?? FieldValue.serverTimestamp()
  }, { merge: true });
  await db.doc(`wallets/${uid}`).set({ balance: 0, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
});

export const approveUser = onCall(async (request) => {
  const actor = requireModerator(request);
  const uid = String(request.data?.uid ?? "");
  if (!uid || uid === actor.uid) throw new HttpsError("invalid-argument", "Valid target uid required.");
  const userRef = db.doc(`users/${uid}`);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(userRef);
    if (!snap.exists) throw new HttpsError("not-found", "User not found.");
    if (snap.get("role") === "owner") throw new HttpsError("failed-precondition", "Owner account is protected.");
    tx.update(userRef, { status: "approved", approvedAt: FieldValue.serverTimestamp(), approvedBy: actor.uid });
    tx.create(db.collection("adminAuditLogs").doc(), {
      action: "approve_user", actorUid: actor.uid, targetUid: uid, createdAt: FieldValue.serverTimestamp()
    });
  });
  return { ok: true };
});

export const blockUser = onCall(async (request) => {
  const actor = requireModerator(request);
  const uid = String(request.data?.uid ?? "");
  const reason = String(request.data?.reason ?? "Policy violation").slice(0, 300);
  if (!uid || uid === actor.uid) throw new HttpsError("invalid-argument", "Valid target uid required.");
  const ref = db.doc(`users/${uid}`);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError("not-found", "User not found.");
    if (snap.get("role") === "owner") throw new HttpsError("permission-denied", "Owner cannot be blocked.");
    tx.update(ref, { status: "blocked", blockedReason: reason, blockedAt: FieldValue.serverTimestamp(), blockedBy: actor.uid });
    tx.create(db.collection("adminAuditLogs").doc(), { action:"block_user", actorUid:actor.uid, targetUid:uid, reason, createdAt:FieldValue.serverTimestamp() });
  });
  return { ok: true };
});

// Only an Owner may assign/remove moderators. A moderator cannot appoint another moderator.
export const setModerator = onCall(async (request) => {
  const actor = requireOwner(request);
  const uid = String(request.data?.uid ?? "");
  const enabled = request.data?.enabled === true;
  if (!uid || uid === actor.uid) throw new HttpsError("invalid-argument", "Valid target uid required.");
  const user = await getAuth().getUser(uid);
  if (user.customClaims?.role === "owner") throw new HttpsError("failed-precondition", "Owner role is immutable here.");
  const role: Role = enabled ? "moderator" : "user";
  await getAuth().setCustomUserClaims(uid, { ...(user.customClaims ?? {}), role });
  await db.doc(`users/${uid}`).set({ role }, { merge: true });
  await db.collection("adminAuditLogs").add({ action:"set_moderator", actorUid:actor.uid, targetUid:uid, role, createdAt:FieldValue.serverTimestamp() });
  return { ok:true, role };
});

// Server-side wallet mutation. Clients must never write wallet balances directly.
export const grantCoins = onCall(async (request) => {
  const actor = requireAdmin(request);
  const uid = String(request.data?.uid ?? "");
  const amount = Number(request.data?.amount);
  const reason = String(request.data?.reason ?? "Admin adjustment").slice(0, 200);
  if (!uid || !Number.isSafeInteger(amount) || amount <= 0 || amount > 1_000_000) {
    throw new HttpsError("invalid-argument", "Valid uid and positive coin amount required.");
  }
  const userSnap = await db.doc(`users/${uid}`).get();
  if (!userSnap.exists) throw new HttpsError("not-found", "User not found.");
  if (userSnap.get("role") === "owner") throw new HttpsError("failed-precondition", "Owner wallet is separate and not modified by this function.");
  const walletRef = db.doc(`wallets/${uid}`);
  await db.runTransaction(async (tx) => {
    const wallet = await tx.get(walletRef);
    const balance = Number(wallet.get("balance") ?? 0);
    tx.set(walletRef, { balance: balance + amount, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    tx.create(db.collection("walletTransactions").doc(), {
      uid, type:"admin_credit", amount, reason, actorUid:actor.uid, createdAt:FieldValue.serverTimestamp()
    });
    tx.create(db.collection("adminAuditLogs").doc(), {
      action:"grant_coins", actorUid:actor.uid, targetUid:uid, amount, reason, createdAt:FieldValue.serverTimestamp()
    });
  });
  return { ok:true };
});

// Record a room gift event; coin debit and event creation happen atomically.
export const sendRoomGift = onCall(async (request) => {
  const auth = requireAuth(request);
  const uid = auth.uid;
  const roomId = String(request.data?.roomId ?? "");
  const giftId = String(request.data?.giftId ?? "");
  if (!roomId || !giftId) throw new HttpsError("invalid-argument", "roomId and giftId required.");
  const [userSnap, roomSnap, giftSnap] = await Promise.all([
    db.doc(`users/${uid}`).get(), db.doc(`rooms/${roomId}`).get(), db.doc(`gifts/${giftId}`).get()
  ]);
  if (userSnap.get("status") !== "approved") throw new HttpsError("permission-denied", "Account approval required.");
  if (!roomSnap.exists || roomSnap.get("status") !== "live") throw new HttpsError("failed-precondition", "Room is not live.");
  if (!giftSnap.exists || giftSnap.get("enabled") !== true) throw new HttpsError("not-found", "Gift unavailable.");
  const price = Number(giftSnap.get("price"));
  if (!Number.isSafeInteger(price) || price <= 0) throw new HttpsError("failed-precondition", "Invalid gift price.");
  const walletRef = db.doc(`wallets/${uid}`);
  const eventRef = db.collection(`rooms/${roomId}/giftEvents`).doc();
  await db.runTransaction(async (tx) => {
    const wallet = await tx.get(walletRef);
    const balance = Number(wallet.get("balance") ?? 0);
    if (balance < price) throw new HttpsError("failed-precondition", "Not enough coins.");
    tx.update(walletRef, { balance: balance - price, updatedAt: FieldValue.serverTimestamp() });
    tx.create(db.collection("walletTransactions").doc(), {
      uid, type:"gift_spend", amount:-price, giftId, roomId, createdAt:FieldValue.serverTimestamp()
    });
    tx.create(eventRef, {
      senderUid:uid, giftId, giftName:giftSnap.get("name"), price,
      animationKey:giftSnap.get("animationKey") ?? "default",
      createdAt:FieldValue.serverTimestamp()
    });
  });
  return { ok:true, giftEventId:eventRef.id };
});

// Admins can change gift catalogue; price changes are audited.
export const upsertGift = onCall(async (request) => {
  const actor = requireAdmin(request);
  const giftId = String(request.data?.giftId ?? "");
  const name = String(request.data?.name ?? "").trim().slice(0, 60);
  const price = Number(request.data?.price);
  const enabled = request.data?.enabled !== false;
  const animationKey = String(request.data?.animationKey ?? "default").slice(0, 80);
  if (!giftId || !name || !Number.isSafeInteger(price) || price < 1 || price > 10_000_000) {
    throw new HttpsError("invalid-argument", "Valid giftId, name and price required.");
  }
  await db.doc(`gifts/${giftId}`).set({ name, price, enabled, animationKey, updatedAt:FieldValue.serverTimestamp(), updatedBy:actor.uid }, { merge:true });
  await db.collection("adminAuditLogs").add({ action:"upsert_gift", actorUid:actor.uid, giftId, price, createdAt:FieldValue.serverTimestamp() });
  return { ok:true };
});

// Daily operational counters. Add client Analytics/Crashlytics SDKs for user-facing analytics.
export const trackRoomCreated = onDocumentCreated("rooms/{roomId}", async (event) => {
  const day = new Date().toISOString().slice(0,10);
  await db.doc(`appMetricsDaily/${day}`).set({
    roomsCreated: FieldValue.increment(1),
    updatedAt: FieldValue.serverTimestamp()
  }, { merge:true });
  logger.info("Room created", { roomId:event.params.roomId });
});
