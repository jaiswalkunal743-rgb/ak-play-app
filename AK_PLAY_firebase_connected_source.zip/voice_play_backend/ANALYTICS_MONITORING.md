# Analytics and monitoring plan

## Flutter packages
Add and initialize:
- `firebase_analytics`
- `firebase_crashlytics`
- `firebase_performance`
- `firebase_app_check`

## Recommended events
- `sign_up_started`, `sign_up_completed`
- `registration_submitted`, `registration_approved`
- `room_created`, `room_joined`, `room_left`
- `gift_sent` (gift ID and coin price only; no private message content)
- `vip_purchase_started`, `vip_purchase_verified`
- `coin_purchase_verified`
- `moderation_action`

Do not send phone numbers, OTPs, UPI PINs, payment tokens, private messages or other sensitive data as Analytics parameters.

## Operational dashboards and alerts
Monitor Cloud Functions error rate, invocation count, p95 latency, Firestore reads/writes, authentication failures, App Check rejections and billing budget. Configure alert policies in Google Cloud Monitoring and budget alerts in Google Cloud Billing. Set Crashlytics alerts for new fatal issues and regressions.

## Privacy
Publish a privacy policy, obtain required consent, configure retention and deletion workflows, and review applicable India data-protection requirements before launch.
