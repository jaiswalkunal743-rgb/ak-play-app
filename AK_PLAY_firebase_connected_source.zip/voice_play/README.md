# AK PLAY — Flutter + Firebase + Agora

AK PLAY is a dark-purple/pink social audio app starter for Android and iOS. This project includes the Flutter app foundation, registration approval gate, role-aware admin console, moderator management UI, callable Cloud Functions for privileged actions, Firestore rules, Storage rules, and a Super Admin bootstrap script.

> **Release status:** This is an implementation foundation, not a deployed production service or store-ready release. Firebase/Agora projects, platform signing, deployment, and end-to-end security testing are required. The app does not contain production credentials.

## App capabilities included

- Email/password registration and login.
- New accounts are created with `approvalStatus: pending`; pending and blocked accounts cannot enter the approved app shell.
- Super Admin and Moderator roles are read from the user's Firestore profile for navigation; callable backend actions independently verify Firebase custom claims.
- Admin Console: pending registration review, user list and block/unblock, active room closure, moderator list/appointment/removal, and audit log view.
- Moderator permissions: `approveUsers`, `manageUsers`, `blockUsers`, `manageRooms`, `viewAuditLogs`.
- Super Admin-only actions: appoint/remove moderators and assign moderator permissions.
- Callable Cloud Functions perform privileged changes with the Admin SDK and write audit records.
- Firestore rules prevent clients from changing approval state, role, blocked state, room lifecycle, or audit logs.
- Storage rules restrict photo uploads to the owner's user path, approved accounts, image MIME types, and files below 12 MiB.

## Requirements

- Flutter stable (3.24+ recommended), Dart 3.3+
- Node.js 20 and npm
- Firebase CLI (`npm i -g firebase-tools`)
- FlutterFire CLI (`dart pub global activate flutterfire_cli`)
- Android Studio / Android SDK; Xcode on macOS for iOS builds
- A Firebase project with Authentication, Firestore, Storage, and Cloud Functions enabled (Blaze billing may be required for deployed functions)
- Agora project for live voice

## Firebase Android configuration

The supplied Firebase Android configuration has been placed at
`android/app/google-services.json` for project `ak-play-77d05` and package
`com.akplay.socialgame`.

This does **not** mean Firebase is fully enabled or the APK is ready. The Android
Gradle project still needs to be generated/configured, Firebase products must be
enabled in the Firebase Console, and the app must be built and tested.

The JSON contains a Firebase client API key. It is not an admin credential, but
keep database access protected with the included Firestore/Storage rules. Never
share service-account files, private signing keys, passwords, or OTPs.

## 1. Configure Flutter and Firebase

From this directory:

```bash
flutter create --platforms=android,ios .
flutter pub get
dart pub global activate flutterfire_cli
flutterfire configure
```

The FlutterFire command creates `lib/firebase_options.dart`. Initialize Firebase with those generated options in `lib/main.dart` for each platform. Add platform-specific configuration through FlutterFire; do not commit service-account JSON, Agora App Certificates, or private tokens.

Enable Email/Password in Firebase Authentication. Create Firestore and Storage. Configure Android/iOS bundle identifiers and signing before release.

## 2. Deploy security rules and callable functions

At the project root, select your Firebase project and deploy:

```bash
firebase login
firebase use --add
cd functions
npm install
npm run build
cd ..
firebase deploy --only functions,firestore:rules,firestore:indexes,storage
```

The functions expose these privileged actions:

- `reviewRegistration` — approve/reject pending registrations.
- `setUserBlocked` — block/unblock accounts.
- `setModerator` / `removeModerator` — Super Admin-only moderator role management.
- `closeVoiceRoom` — close a room and record who closed it.
- `createModeratorInvite` — Super Admin-only helper to appoint a registered account by email with the standard permission set.

All callable functions verify the caller's Firebase custom claims. The mobile app cannot grant itself staff status. Admin SDK operations bypass Firestore client rules by design; all callable entry points therefore perform their own role and permission checks.

## 3. Set up the first Super Admin

1. Register the account you want to use as the owner of AK PLAY.
2. Confirm the account exists in Firebase Authentication and its `users/{uid}` profile exists.
3. Run the bootstrap script from a trusted machine with a service account that has permission to manage Firebase Authentication and Firestore:

```bash
cd ak_play/functions
npm install
GOOGLE_APPLICATION_CREDENTIALS=/secure/path/service-account.json \
FIREBASE_PROJECT_ID=your-firebase-project-id \
SUPER_ADMIN_EMAIL=you@example.com \
node scripts/bootstrap-super-admin.cjs
```

The script sets the custom claim `role: super_admin`, changes the profile to `approvalStatus: approved`, and sets `role: super_admin`. The first Super Admin is the trust anchor for moderator appointment. Never run this script from the app or expose the service account to clients. Sign out and back in after bootstrap so the client receives a refreshed ID token.

## 4. Admin and moderator workflow

### Registration review

1. A new registration creates a Firebase Auth account and a `users/{uid}` profile with `approvalStatus: pending` and `role: user`.
2. The user sees the pending approval screen and cannot access approved community content.
3. A Super Admin or moderator with `approveUsers` can approve or reject the account from Admin Console → Pending.
4. The callable function changes the profile state and writes an immutable-to-client audit entry.

### Moderator appointment

1. The Super Admin opens Admin Console → Moderators → Add moderator.
2. Enter the registered account's Firebase Auth UID and select permissions.
3. The callable function sets custom claims and updates the profile role. Only the Super Admin can appoint or remove moderators.
4. The new moderator must sign out and sign back in to refresh their custom claims.

### Moderation

- Users: review user status and block/unblock accounts (requires `manageUsers` / `blockUsers`).
- Rooms: close active rooms (requires `manageRooms`).
- Audit log: view moderation events (requires `viewAuditLogs`).
- Moderators cannot appoint other moderators, edit role claims, alter audit logs, or moderate Super Admin accounts.

## 5. Firestore and Storage security

`firestore.rules` and `storage.rules` are included. They are intentionally restrictive:

- Users can create only their own pending, ordinary-user profile.
- Clients cannot update their own approval state, role, or blocked state.
- Staff access is based on Firebase custom claims, not editable profile fields.
- Voice-room lifecycle changes are server-controlled; clients cannot directly close or delete rooms.
- Private room reads require membership. A production invite flow still needs a trusted invite-code verifier and server-authorized membership writes.
- Admin audit logs are server-write-only.
- Photo uploads are limited to the owner's path, approved/unblocked accounts, images, and under 12 MiB.

Before launch, test rules and callable functions using Firebase Emulator Suite, including cross-role tests and attempts to forge user profile fields.

## 6. Remaining product integrations

- **Live voice:** Agora SDK is included in `pubspec.yaml`, but the real RTC join/mute/speaker controller and secure short-lived token issuer still need to be implemented. Never embed the Agora App Certificate or permanent tokens in Flutter. Implement a backend token endpoint that verifies account approval, room membership, and speaker permissions.
- **Music:** Connect `just_audio` to licensed audio URLs or local files you own. Do not rebroadcast copyrighted commercial music without rights.
- **Photos:** The current picker UI is local-only; connect Firebase Storage upload/download and album metadata before launch.
- **Private rooms:** Implement invite links/codes with hashed secrets, rate limits, expiration, and server-side membership authorization.
- **Operations:** Add account deletion, reporting/appeals, privacy policy, terms, abuse escalation, push notifications, rate limits, and support contact details.

## 7. Run and build

```bash
flutter pub get
flutter run
flutter build apk --release
flutter build appbundle --release
flutter build ipa --release  # macOS + Xcode + Apple signing required
```

An APK/IPA cannot be produced in this environment unless Flutter, Android build tooling, Xcode (for iOS), signing assets, and configured Firebase platform files are available. A successful source archive is not evidence of a tested or publishable binary.

## Gift store and room gifting
- The Gifts tab includes the romantic/premium gift catalog, recipient and room ID entry, coin wallet display, and Top Gift Receivers leaderboard.
- `sendRoomGift` is a callable Cloud Function. It checks approved users, active room membership for private rooms, server-defined gift prices, and coin balance, then atomically debits/credits wallets, updates leaderboard totals, and creates a room gift event.
- The Gifts tab listens to the latest event for the entered room ID and displays a full-screen animation. Everyone who has the same room ID open and is authorized to read that room's events receives the event.
- Coin purchase crediting is intentionally not implemented as a client-side balance write. Add verified Google Play Billing and Apple In-App Purchase receipt validation before selling coins; never trust a client-supplied purchase success callback.
- Deploy the updated Firestore rules and Cloud Functions before enabling gifting. Ensure room membership documents are created by the room join flow.

## 8. VIP subscriptions (Silver / Gold / Diamond)

The app includes a VIP tab with three monthly subscription product IDs:

- `voice_play_vip_silver_monthly` — proposed ₹99/month
- `voice_play_vip_gold_monthly` — proposed ₹199/month
- `voice_play_vip_diamond_monthly` — proposed ₹499/month

The UI displays the localized price returned by Google Play / App Store when available, with the proposed price as a fallback. It includes purchase-stream handling, restore purchases, an active-membership/expiry panel, and a profile VIP badge. The Super Admin gets Admin Console → VIP to grant 30-day promotional memberships or revoke them. VIP entitlement documents are server-write-only and the scheduled `expireVipMemberships` function expires memberships hourly.

**Paid subscriptions are not ready to activate.** `verifyVipPurchase` deliberately fails closed until Google Play Developer API and Apple App Store Server API verification are implemented and configured with server-side credentials. Before launch, implement token/JWS verification, transaction deduplication, renewals, refunds/revocations, billing retry/grace periods, and store server notifications. Follow `VIP_SETUP.md`. Never grant a paid entitlement from a client-side purchase callback alone.


## Branding update
The app display name and visible interface branding have been changed to **AK PLAY**. The supplied AK PLAY logo is included at `assets/ak_play_logo.png`.

## Important implementation gaps
This source currently uses email/password authentication, not phone OTP. Live audio requires valid Agora credentials and a production token-generation flow. Coin purchases and VIP purchases require store billing integration and server-side receipt verification. Analytics/Crashlytics SDK setup and privacy configuration are not yet complete. Do not publish or handle real payments until these are implemented and independently tested.


## Analytics and crash/performance monitoring

The Flutter dependencies now include Firebase Analytics, Crashlytics and Performance Monitoring. App startup records `app_open`, forwards uncaught Flutter/platform errors to Crashlytics, and enables Performance Monitoring after Firebase initialization. Before release, verify Android Firebase configuration includes the Crashlytics Gradle plugin and upload mapping files; configure alerting in Firebase/Google Cloud consoles. Add only privacy-safe product events and never log OTPs, phone numbers, payment tokens, UPI PINs, private messages or authentication secrets.

**Not yet production-complete:** phone OTP flow is not implemented in this source (the current auth screen uses email/password); Agora live audio token issuance and RTC join flow remain; purchase verification remains deliberately disabled; Firebase platform config, deployment, privacy/consent configuration, and device testing remain required.
