// Run once from a trusted machine after `firebase login` and selecting your project.
// Usage: GOOGLE_APPLICATION_CREDENTIALS=/secure/service-account.json \
//        FIREBASE_PROJECT_ID=your-project-id SUPER_ADMIN_EMAIL=you@example.com node scripts/bootstrap-super-admin.cjs
// Never bundle service-account credentials in the mobile app or commit them.
const admin = require('firebase-admin');
const projectId = process.env.FIREBASE_PROJECT_ID;
const email = process.env.SUPER_ADMIN_EMAIL;
if (!projectId || !email) throw new Error('Set FIREBASE_PROJECT_ID and SUPER_ADMIN_EMAIL.');
admin.initializeApp({ credential: admin.credential.applicationDefault(), projectId });
(async () => {
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, { ...(user.customClaims || {}), role: 'super_admin' });
  await admin.firestore().collection('users').doc(user.uid).set({
    role: 'super_admin', approvalStatus: 'approved', blocked: false,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  }, { merge: true });
  console.log(`Granted Super Admin to ${email} (${user.uid}). Sign out and sign in again to refresh claims.`);
  process.exit(0);
})().catch((error) => { console.error(error); process.exit(1); });
