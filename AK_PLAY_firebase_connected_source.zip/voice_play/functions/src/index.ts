import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { onSchedule } from 'firebase-functions/v2/scheduler';

initializeApp();
const db = getFirestore();
type StaffRole = 'super_admin' | 'moderator';
type StaffClaims = { role?: StaffRole; permissions?: Record<string, boolean> };
type StaffActor = { uid: string; role: StaffRole; permissions: Record<string, boolean> };

async function caller(request: { auth?: { uid: string; token: Record<string, unknown> } }): Promise<StaffActor> {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in is required.');
  const token = request.auth.token as StaffClaims;
  if (token.role !== 'super_admin' && token.role !== 'moderator') {
    throw new HttpsError('permission-denied', 'Administrator access is required.');
  }
  // Claims alone are not enough: check the live profile so blocked or demoted staff
  // lose backend privileges immediately, even while an old ID token is cached.
  const profile = await db.collection('users').doc(request.auth.uid).get();
  if (!profile.exists || profile.get('approvalStatus') !== 'approved' || profile.get('blocked') === true || profile.get('role') !== token.role) {
    throw new HttpsError('permission-denied', 'This staff account is inactive or its role has changed. Sign in again if your role was recently updated.');
  }
  const permissions = token.role === 'super_admin' ? {
    approveUsers: true, manageUsers: true, blockUsers: true, manageRooms: true,
    manageModerators: true, viewAuditLogs: true,
  } : (token.permissions ?? {});
  return { uid: request.auth.uid, role: token.role, permissions };
}

function requirePermission(actor: StaffActor, permission: string): void {
  if (actor.role !== 'super_admin' && actor.permissions[permission] !== true) {
    throw new HttpsError('permission-denied', `Missing permission: ${permission}`);
  }
}

async function audit(actorUid: string, action: string, targetUid: string, details: Record<string, unknown> = {}) {
  await db.collection('adminAuditLogs').add({
    actorUid, action, targetUid, details, createdAt: FieldValue.serverTimestamp(),
  });
}

export const reviewRegistration = onCall(async (request) => {
  const actor = await caller(request);
  requirePermission(actor, 'approveUsers');
  const uid = String(request.data?.uid ?? '');
  const decision = String(request.data?.decision ?? '');
  if (!uid || !['approve', 'reject'].includes(decision)) throw new HttpsError('invalid-argument', 'A valid user and decision are required.');
  if (uid === actor.uid) throw new HttpsError('failed-precondition', 'You cannot review your own account.');
  const ref = db.collection('users').doc(uid);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'User profile not found.');
  if (snap.get('role') === 'super_admin' || (actor.role !== 'super_admin' && snap.get('role') === 'moderator')) throw new HttpsError('permission-denied', 'You cannot review this staff account.');
  const status = decision === 'approve' ? 'approved' : 'rejected';
  await ref.update({ approvalStatus: status, reviewedBy: actor.uid, reviewedAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp() });
  await audit(actor.uid, `registration_${decision}`, uid);
  return { ok: true, approvalStatus: status };
});

export const setUserBlocked = onCall(async (request) => {
  const actor = await caller(request);
  requirePermission(actor, 'blockUsers');
  const uid = String(request.data?.uid ?? '');
  const blocked = request.data?.blocked;
  if (!uid || typeof blocked !== 'boolean') throw new HttpsError('invalid-argument', 'A user ID and blocked boolean are required.');
  if (uid === actor.uid) throw new HttpsError('failed-precondition', 'You cannot block yourself.');
  const ref = db.collection('users').doc(uid);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'User profile not found.');
  if (snap.get('role') === 'super_admin' || (actor.role !== 'super_admin' && snap.get('role') === 'moderator')) throw new HttpsError('permission-denied', 'You cannot block this staff account.');
  await ref.update({ blocked, blockedBy: blocked ? actor.uid : null, blockedAt: blocked ? FieldValue.serverTimestamp() : null, updatedAt: FieldValue.serverTimestamp() });
  await audit(actor.uid, blocked ? 'user_blocked' : 'user_unblocked', uid);
  return { ok: true };
});

export const setModerator = onCall(async (request) => {
  const actor = await caller(request);
  if (actor.role !== 'super_admin') throw new HttpsError('permission-denied', 'Only the Super Admin can appoint moderators.');
  const identifier = String(request.data?.userIdentifier ?? request.data?.uid ?? '').trim();
  const raw = request.data?.permissions;
  if (!identifier || !raw || typeof raw !== 'object') throw new HttpsError('invalid-argument', 'An account email/UID and permission map are required.');
  const user = await (identifier.includes('@') ? getAuth().getUserByEmail(identifier.toLowerCase()) : getAuth().getUser(identifier))
    .catch(() => { throw new HttpsError('not-found', 'The Voice Play account was not found. Ask the person to register first.'); });
  const uid = user.uid;
  if (uid === actor.uid) throw new HttpsError('failed-precondition', 'The Super Admin cannot be changed into a moderator.');
  const allowed = ['approveUsers', 'manageUsers', 'blockUsers', 'manageRooms', 'viewAuditLogs'];
  const permissions: Record<string, boolean> = {};
  for (const key of allowed) permissions[key] = (raw as Record<string, unknown>)[key] === true;
  const targetProfile = await db.collection('users').doc(uid).get();
  if (!targetProfile.exists) throw new HttpsError('not-found', 'The user must complete registration first.');
  if (targetProfile.get('role') === 'super_admin') throw new HttpsError('failed-precondition', 'The Super Admin cannot be reassigned.');
  const previous = (user.customClaims ?? {}) as Record<string, unknown>;
  await getAuth().setCustomUserClaims(uid, { ...previous, role: 'moderator', permissions });
  await db.collection('users').doc(uid).set({ role: 'moderator', permissions, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  await audit(actor.uid, 'moderator_appointed', uid, { permissions });
  return { ok: true, note: 'The moderator must refresh their ID token to receive updated permissions.' };
});

export const removeModerator = onCall(async (request) => {
  const actor = await caller(request);
  if (actor.role !== 'super_admin') throw new HttpsError('permission-denied', 'Only the Super Admin can remove moderators.');
  const uid = String(request.data?.uid ?? '');
  if (!uid || uid === actor.uid) throw new HttpsError('invalid-argument', 'A different user ID is required.');
  const user = await getAuth().getUser(uid);
  if ((user.customClaims as StaffClaims | undefined)?.role !== 'moderator') throw new HttpsError('failed-precondition', 'This user is not a moderator.');
  const claims = { ...(user.customClaims ?? {}) } as Record<string, unknown>;
  delete claims.role;
  delete claims.permissions;
  await getAuth().setCustomUserClaims(uid, claims);
  await db.collection('users').doc(uid).set({ role: 'user', permissions: FieldValue.delete(), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  await audit(actor.uid, 'moderator_removed', uid);
  return { ok: true };
});

export const closeVoiceRoom = onCall(async (request) => {
  const actor = await caller(request);
  requirePermission(actor, 'manageRooms');
  const roomId = String(request.data?.roomId ?? '');
  if (!roomId) throw new HttpsError('invalid-argument', 'Room ID is required.');
  const ref = db.collection('voiceRooms').doc(roomId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Room not found.');
  await ref.update({ status: 'closed', closedBy: actor.uid, closedAt: FieldValue.serverTimestamp() });
  await audit(actor.uid, 'voice_room_closed', roomId);
  return { ok: true };
});

export const createModeratorInvite = onCall(async (request) => {
  const actor = await caller(request);
  if (actor.role !== 'super_admin') throw new HttpsError('permission-denied', 'Only the Super Admin can create moderator invitations.');
  const email = String(request.data?.email ?? '').trim().toLowerCase();
  if (!email.includes('@')) throw new HttpsError('invalid-argument', 'A valid email address is required.');
  const user = await getAuth().getUserByEmail(email).catch(() => null);
  if (!user) throw new HttpsError('not-found', 'The person must register for Voice Play before moderator access can be granted.');
  const defaults = { approveUsers: true, manageUsers: true, blockUsers: true, manageRooms: true, viewAuditLogs: false };
  const existing = (user.customClaims ?? {}) as Record<string, unknown>;
  await getAuth().setCustomUserClaims(user.uid, { ...existing, role: 'moderator', permissions: defaults });
  await db.collection('users').doc(user.uid).set({ role: 'moderator', permissions: defaults, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
  await audit(actor.uid, 'moderator_appointed', user.uid, { email });
  return { ok: true, uid: user.uid };
});

const giftCatalog: Record<string, { name: string; emoji: string; coins: number }> = {
  rose: { name: 'Rose', emoji: '🌹', coins: 10 }, heart: { name: 'Love Heart', emoji: '💖', coins: 50 },
  cupid: { name: 'Cupid', emoji: '💘', coins: 100 }, teddy: { name: 'Teddy Bear', emoji: '🧸', coins: 200 },
  ring: { name: 'Diamond Ring', emoji: '💍', coins: 500 }, love_box: { name: 'Love Box', emoji: '💝', coins: 1000 },
  diamond: { name: 'Diamond', emoji: '💎', coins: 2000 }, unicorn: { name: 'Unicorn', emoji: '🦄', coins: 3000 },
  crown: { name: 'Crown', emoji: '👑', coins: 5000 }, phoenix: { name: 'Phoenix', emoji: '🔥', coins: 8000 },
  car: { name: 'Sports Car', emoji: '🏎️', coins: 10000 }, dragon: { name: 'Dragon', emoji: '🐉', coins: 15000 },
  jet: { name: 'Private Jet', emoji: '🛩️', coins: 20000 }, yacht: { name: 'Yacht', emoji: '🛥️', coins: 30000 },
  castle: { name: 'Castle', emoji: '🏰', coins: 50000 },
};

// Coin balances are changed only inside this trusted callable transaction.
// A verified in-app purchase backend must credit purchased coins separately.
export const sendRoomGift = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in is required.');
  const senderUid = request.auth.uid;
  const roomId = String(request.data?.roomId ?? '').trim();
  const receiverUid = String(request.data?.receiverUid ?? '').trim();
  const giftId = String(request.data?.giftId ?? '').trim();
  const gift = giftCatalog[giftId];
  if (!roomId || !receiverUid || !gift) throw new HttpsError('invalid-argument', 'A valid room, receiver and gift are required.');
  if (senderUid === receiverUid) throw new HttpsError('failed-precondition', 'You cannot send a gift to yourself.');
  const senderRef = db.collection('users').doc(senderUid);
  const receiverRef = db.collection('users').doc(receiverUid);
  const roomRef = db.collection('voiceRooms').doc(roomId);
  const senderWallet = db.collection('coinWallets').doc(senderUid);
  const receiverWallet = db.collection('coinWallets').doc(receiverUid);
  const senderRank = db.collection('giftLeaderboard').doc(senderUid);
  const receiverRank = db.collection('giftLeaderboard').doc(receiverUid);
  const eventRef = roomRef.collection('giftEvents').doc();
  await db.runTransaction(async (tx) => {
    const [senderSnap, receiverSnap, roomSnap, senderWalletSnap, receiverWalletSnap] = await Promise.all([
      tx.get(senderRef), tx.get(receiverRef), tx.get(roomRef), tx.get(senderWallet), tx.get(receiverWallet),
    ]);
    if (!senderSnap.exists || senderSnap.get('approvalStatus') !== 'approved' || senderSnap.get('blocked') === true) throw new HttpsError('permission-denied', 'Your account is not approved.');
    if (!receiverSnap.exists || receiverSnap.get('approvalStatus') !== 'approved' || receiverSnap.get('blocked') === true) throw new HttpsError('failed-precondition', 'The recipient is unavailable.');
    if (!roomSnap.exists || roomSnap.get('status') !== 'active') throw new HttpsError('not-found', 'The active voice room was not found.');
    if (roomSnap.get('isPrivate') === true) {
      const senderMember = await tx.get(roomRef.collection('members').doc(senderUid));
      const receiverMember = await tx.get(roomRef.collection('members').doc(receiverUid));
      if (!senderMember.exists || !receiverMember.exists) throw new HttpsError('permission-denied', 'Both users must be members of this private room.');
    }
    const balance = Number(senderWalletSnap.get('balance') ?? 0);
    if (balance < gift.coins) throw new HttpsError('failed-precondition', 'Not enough coins. Please purchase a coin package.');
    const senderName = String(senderSnap.get('displayName') ?? 'Voice Play user');
    const receiverName = String(receiverSnap.get('displayName') ?? 'Voice Play user');
    tx.set(senderWallet, { balance: balance - gift.coins, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    tx.set(receiverWallet, { balance: Number(receiverWalletSnap.get('balance') ?? 0) + gift.coins, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    tx.set(senderRank, { displayName: senderName, totalSent: FieldValue.increment(gift.coins), giftsSent: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    tx.set(receiverRank, { displayName: receiverName, totalReceived: FieldValue.increment(gift.coins), giftsReceived: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    tx.set(eventRef, { senderUid, senderName, receiverUid, receiverName, giftId, giftName: gift.name, emoji: gift.emoji, coins: gift.coins, createdAt: FieldValue.serverTimestamp() });
  });
  return { ok: true, giftName: gift.name, coins: gift.coins };
});

// VIP entitlements are server-owned. Manual grants/revocations are restricted
// to the Super Admin and always written with an expiry timestamp.
export const setVipEntitlement = onCall(async (request) => {
  const actor = await caller(request);
  if (actor.role !== 'super_admin') throw new HttpsError('permission-denied', 'Only the Super Admin can manage VIP memberships.');
  const uid = String(request.data?.uid ?? '').trim();
  const tier = String(request.data?.tier ?? '').trim();
  const active = request.data?.active;
  const days = Math.max(1, Math.min(365, Number(request.data?.days ?? 30)));
  if (!uid || !['silver', 'gold', 'diamond'].includes(tier) || typeof active !== 'boolean') {
    throw new HttpsError('invalid-argument', 'A valid user, VIP tier and active flag are required.');
  }
  const user = await db.collection('users').doc(uid).get();
  if (!user.exists) throw new HttpsError('not-found', 'Voice Play user not found.');
  const ref = db.collection('vipSubscriptions').doc(uid);
  await ref.set({
    uid, tier, status: active ? 'active' : 'revoked',
    source: 'admin', updatedBy: actor.uid,
    startedAt: active ? FieldValue.serverTimestamp() : FieldValue.delete(),
    expiresAt: active ? new Date(Date.now() + days * 24 * 60 * 60 * 1000) : FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  }, { merge: true });
  await db.collection('users').doc(uid).set({ vipTier: active ? tier : FieldValue.delete(), vipStatus: active ? 'active' : 'revoked' }, { merge: true });
  await audit(actor.uid, active ? 'vip_granted' : 'vip_revoked', uid, { tier, days });
  return { ok: true };
});

// Deliberately fail closed until Google Play Developer API and Apple App Store
// Server API credentials are configured and the purchase token/JWS is verified.
// Never trust client-supplied purchase state to grant paid membership.
export const verifyVipPurchase = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in is required.');
  const productId = String(request.data?.productId ?? '');
  const allowed = ['voice_play_vip_silver_monthly', 'voice_play_vip_gold_monthly', 'voice_play_vip_diamond_monthly'];
  if (!allowed.includes(productId)) throw new HttpsError('invalid-argument', 'Unknown VIP product.');
  throw new HttpsError('failed-precondition', 'Store purchase verification is not configured yet. Configure Google Play Developer API and Apple App Store Server API verification before enabling paid VIP activation.');
});


// Expire memberships server-side so badges and access do not rely only on client clocks.
export const expireVipMemberships = onSchedule('every 60 minutes', async () => {
  const now = new Date();
  const expired = await db.collection('vipSubscriptions')
    .where('status', '==', 'active').where('expiresAt', '<=', now).limit(400).get();
  if (expired.empty) return;
  const batch = db.batch();
  for (const doc of expired.docs) {
    batch.update(doc.ref, { status: 'expired', updatedAt: FieldValue.serverTimestamp() });
    batch.set(db.collection('users').doc(doc.id), { vipStatus: 'expired', vipTier: FieldValue.delete() }, { merge: true });
  }
  await batch.commit();
});
