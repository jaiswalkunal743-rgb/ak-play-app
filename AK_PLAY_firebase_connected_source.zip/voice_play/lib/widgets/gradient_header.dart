import 'package:flutter/material.dart';
import '../main.dart';

class GradientHeader extends StatelessWidget {
  const GradientHeader({super.key, required this.title, this.subtitle});
  final String title; final String? subtitle;
  @override Widget build(BuildContext context) => Container(
    width: double.infinity, padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF512A75), Color(0xFF251638), Color(0xFF3B1D42)])),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [Icon(Icons.favorite, color: AkPlayApp.pink), SizedBox(width: 8), Text('AK PLAY', style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.bold, color: Colors.white70))]),
      const SizedBox(height: 18), Text(title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
      if (subtitle != null) ...[const SizedBox(height: 6), Text(subtitle!, style: const TextStyle(color: Colors.white70))],
    ]),
  );
}
