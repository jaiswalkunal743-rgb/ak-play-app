import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AdminService {
  AdminService({FirebaseFirestore? firestore, FirebaseFunctions? functions})
      : _db = firestore ?? FirebaseFirestore.instance,
        _functions = functions ?? FirebaseFunctions.instance;

  final FirebaseFirestore _db;
  final FirebaseFunctions _functions;

  Stream<DocumentSnapshot<Map<String, dynamic>>> myProfile() {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return _db.collection('users').doc(uid).snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> pendingUsers() => _db
      .collection('users')
      .where('approvalStatus', isEqualTo: 'pending')
      .orderBy('createdAt')
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> allUsers() =>
      _db.collection('users').orderBy('createdAt', descending: true).limit(100).snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> activeRooms() => _db
      .collection('voiceRooms')
      .where('status', isEqualTo: 'active')
      .orderBy('createdAt', descending: true)
      .limit(100)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> auditLogs() => _db
      .collection('adminAuditLogs')
      .orderBy('createdAt', descending: true)
      .limit(100)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> moderators() => _db
      .collection('users')
      .where('role', isEqualTo: 'moderator')
      .snapshots();

  Future<void> approveUser(String uid) => _call('reviewRegistration', {
        'uid': uid,
        'decision': 'approve',
      });

  Future<void> rejectUser(String uid) => _call('reviewRegistration', {
        'uid': uid,
        'decision': 'reject',
      });

  Future<void> setBlocked(String uid, bool blocked) =>
      _call('setUserBlocked', {'uid': uid, 'blocked': blocked});

  Future<void> setModerator(String userIdentifier, Map<String, bool> permissions) =>
      _call('setModerator', {'userIdentifier': userIdentifier, 'permissions': permissions});

  Future<void> removeModerator(String uid) => _call('removeModerator', {'uid': uid});

  Future<void> closeRoom(String roomId) => _call('closeVoiceRoom', {'roomId': roomId});

  Future<void> _call(String name, Map<String, dynamic> data) async {
    await _functions.httpsCallable(name).call(data);
  }
}
