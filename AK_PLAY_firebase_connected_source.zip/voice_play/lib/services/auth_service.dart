import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;
  Stream<User?> get authState => _auth.authStateChanges();
  User? get currentUser => _auth.currentUser;

  Future<void> register({required String name, required String email, required String password}) async {
    final credential = await _auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
    await credential.user!.updateDisplayName(name.trim());
    await _db.collection('users').doc(credential.user!.uid).set({
      'displayName': name.trim(), 'email': email.trim(), 'approvalStatus': 'pending',
      'role': 'user', 'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<String> approvalStatus(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    return (doc.data()?['approvalStatus'] as String?) ?? 'pending';
  }
  Future<void> signIn({required String email, required String password}) async {
    await _auth.signInWithEmailAndPassword(email: email.trim(), password: password);
  }
  Future<void> signOut() => _auth.signOut();
}
