import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uuid/uuid.dart';

/// Firestore room metadata. Agora handles the real-time audio stream separately.
class VoiceRoomService {
  final _db = FirebaseFirestore.instance;
  final _uuid = const Uuid();
  Future<String> createRoom({required String name, required bool isPrivate}) async {
    final id = _uuid.v4();
    await _db.collection('voiceRooms').doc(id).set({
      'name': name, 'isPrivate': isPrivate, 'ownerId': FirebaseAuth.instance.currentUser!.uid,
      'status': 'active', 'createdAt': FieldValue.serverTimestamp(),
    });
    return id;
  }
}
