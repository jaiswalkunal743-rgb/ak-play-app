import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

class GiftItem {
  final String id, name, emoji;
  final int coins;
  const GiftItem(this.id, this.name, this.emoji, this.coins);
}

const giftCatalog = <GiftItem>[
  GiftItem('rose', 'Rose', '🌹', 10),
  GiftItem('heart', 'Love Heart', '💖', 50),
  GiftItem('cupid', 'Cupid', '💘', 100),
  GiftItem('teddy', 'Teddy Bear', '🧸', 200),
  GiftItem('ring', 'Diamond Ring', '💍', 500),
  GiftItem('love_box', 'Love Box', '💝', 1000),
  GiftItem('diamond', 'Diamond', '💎', 2000),
  GiftItem('unicorn', 'Unicorn', '🦄', 3000),
  GiftItem('crown', 'Crown', '👑', 5000),
  GiftItem('phoenix', 'Phoenix', '🔥', 8000),
  GiftItem('car', 'Sports Car', '🏎️', 10000),
  GiftItem('dragon', 'Dragon', '🐉', 15000),
  GiftItem('jet', 'Private Jet', '🛩️', 20000),
  GiftItem('yacht', 'Yacht', '🛥️', 30000),
  GiftItem('castle', 'Castle', '🏰', 50000),
];

class GiftService {
  final _db = FirebaseFirestore.instance;
  final _functions = FirebaseFunctions.instance;

  Future<void> sendGift({required String roomId, required String receiverUid, required String giftId}) async {
    final call = _functions.httpsCallable('sendRoomGift');
    await call.call({'roomId': roomId, 'receiverUid': receiverUid, 'giftId': giftId});
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchRoomGifts(String roomId) => _db
      .collection('voiceRooms').doc(roomId).collection('giftEvents')
      .orderBy('createdAt', descending: true).limit(1).snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> watchLeaderboard() => _db
      .collection('giftLeaderboard').orderBy('totalReceived', descending: true).limit(20).snapshots();

  Stream<DocumentSnapshot<Map<String, dynamic>>> watchWallet(String uid) => _db.collection('coinWallets').doc(uid).snapshots();
}
