import 'package:cloud_functions/cloud_functions.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

class VipTier {
  final String id, name, productId, price, badge;
  final List<String> benefits;
  const VipTier({required this.id, required this.name, required this.productId, required this.price, required this.badge, required this.benefits});
}

const vipTiers = <VipTier>[
  VipTier(id: 'silver', name: 'Silver VIP', productId: 'ak_play_vip_silver_monthly', price: '₹99 / month', badge: '🥈', benefits: ['Silver VIP badge', 'Exclusive profile frame', 'Silver gift collection']),
  VipTier(id: 'gold', name: 'Gold VIP', productId: 'ak_play_vip_gold_monthly', price: '₹199 / month', badge: '🥇', benefits: ['Golden VIP badge', 'Animated gold profile frame', 'Gold gifts and room effects']),
  VipTier(id: 'diamond', name: 'Diamond VIP', productId: 'ak_play_vip_diamond_monthly', price: '₹499 / month', badge: '💎', benefits: ['Diamond VIP badge', 'Luxury animated profile frame', 'Exclusive gifts and entrance effect']),
];

class VipService {
  final InAppPurchase store = InAppPurchase.instance;
  final FirebaseFunctions functions = FirebaseFunctions.instance;

  Future<List<ProductDetails>> loadProducts() async {
    if (!await store.isAvailable()) return [];
    final response = await store.queryProductDetails(vipTiers.map((e) => e.productId).toSet());
    if (response.error != null) throw Exception(response.error!.message);
    return response.productDetails;
  }

  Future<void> buy(ProductDetails product) async {
    final param = PurchaseParam(productDetails: product);
    await store.buyNonConsumable(purchaseParam: param);
  }

  // Store transactions are NOT granted from client data. A trusted server must
  // verify the Google Play purchase token / Apple signed transaction first.
  Future<void> submitPurchaseForVerification(PurchaseDetails purchase) async {
    await functions.httpsCallable('verifyVipPurchase').call({
      'productId': purchase.productID,
      'platform': purchase.verificationData.source,
      'serverVerificationData': purchase.verificationData.serverVerificationData,
      'purchaseId': purchase.purchaseID,
    });
  }

  Future<void> setEntitlement({required String uid, required String tier, required bool active, int days = 30}) async {
    await functions.httpsCallable('setVipEntitlement').call({'uid': uid, 'tier': tier, 'active': active, 'days': days});
  }
}
