import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../main.dart';

class GalleryScreen extends StatefulWidget { const GalleryScreen({super.key}); @override State<GalleryScreen> createState()=>_GalleryScreenState(); }
class _GalleryScreenState extends State<GalleryScreen> {
 final picker=ImagePicker(); final List<XFile> photos=[];
 Future<void> addPhoto() async { final f=await picker.pickImage(source:ImageSource.gallery,imageQuality:85); if(f!=null)setState(()=>photos.add(f)); }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Photo Memories',style:TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(onPressed:addPhoto,icon:const Icon(Icons.add_a_photo,color:AkPlayApp.pink))]),body:photos.isEmpty?Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.photo_library_outlined,size:62,color:AkPlayApp.pink),const SizedBox(height:12),const Text('Your memories start here',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('Add photos from your device'),const SizedBox(height:16),FilledButton.icon(onPressed:addPhoto,icon:const Icon(Icons.add),label:const Text('Add photos'))])):GridView.builder(padding:const EdgeInsets.all(12),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:10,mainAxisSpacing:10),itemCount:photos.length,itemBuilder:(c,i)=>ClipRRect(borderRadius:BorderRadius.circular(16),child:Image.file(File(photos[i].path),fit:BoxFit.cover,errorBuilder:(_,__,___)=>const ColoredBox(color:Color(0xFF21152F),child:Icon(Icons.image))))));
}
