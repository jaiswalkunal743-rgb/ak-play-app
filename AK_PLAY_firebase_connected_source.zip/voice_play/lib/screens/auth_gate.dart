import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'app_shell.dart';
import 'login_screen.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
        stream: AuthService().authState,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const _Loading();
          final user = snapshot.data;
          if (user == null) return const LoginScreen();
          return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
            builder: (context, profile) {
              if (profile.connectionState == ConnectionState.waiting) return const _Loading();
              if (profile.hasError) return const _MessageScreen(message: 'Unable to verify account status. Please try again.');
              final data = profile.data?.data();
              if (data == null) return const PendingApprovalScreen();
              if (data['blocked'] == true) return const BlockedAccountScreen();
              if (data['approvalStatus'] == 'rejected') return const RejectedApprovalScreen();
              if (data['approvalStatus'] != 'approved') return const PendingApprovalScreen();
              final role = (data['role'] ?? 'user').toString();
              return AppShell(isStaff: role == 'super_admin' || role == 'moderator', isSuperAdmin: role == 'super_admin', staffPermissions: Map<String, dynamic>.from(data['permissions'] as Map? ?? const {}));
            },
          );
        },
      );
}

class _Loading extends StatelessWidget {
  const _Loading();
  @override Widget build(BuildContext context) => const Scaffold(body: Center(child: CircularProgressIndicator()));
}

class _MessageScreen extends StatelessWidget {
  const _MessageScreen({required this.message});
  final String message;
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(message, textAlign: TextAlign.center))));
}

class PendingApprovalScreen extends StatelessWidget {
  const PendingApprovalScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.hourglass_top_rounded, size: 64, color: Color(0xFFFF72C6)), const SizedBox(height: 18),
    const Text('You’re on the list!', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
    const Text('Your AK PLAY account is waiting for admin approval. You’ll be able to access the app once your account is approved.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, height: 1.5)),
    const SizedBox(height: 24), OutlinedButton(onPressed: () => AuthService().signOut(), child: const Text('Sign out')),
  ]))));
}

class BlockedAccountScreen extends StatelessWidget {
  const BlockedAccountScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.block_rounded, size: 64, color: Colors.redAccent), const SizedBox(height: 18),
    const Text('Account restricted', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
    const Text('Your account has been blocked by the AK PLAY moderation team. Contact support if you believe this is a mistake.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, height: 1.5)),
    const SizedBox(height: 24), OutlinedButton(onPressed: () => AuthService().signOut(), child: const Text('Sign out')),
  ]))));
}

class RejectedApprovalScreen extends StatelessWidget {
  const RejectedApprovalScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.info_outline_rounded, size: 64, color: Colors.orangeAccent), const SizedBox(height: 18),
    const Text('Registration not approved', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
    const Text('Your AK PLAY registration was not approved. Please contact the app administrator if you need more information.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, height: 1.5)),
    const SizedBox(height: 24), OutlinedButton(onPressed: () => AuthService().signOut(), child: const Text('Sign out')),
  ]))));
}
