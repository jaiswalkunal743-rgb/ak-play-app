import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import '../main.dart';
import '../services/admin_service.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key, required this.isSuperAdmin, this.permissions = const {}});
  final bool isSuperAdmin;
  final Map<String, dynamic> permissions;

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  final _admin = AdminService();
  int _tab = 0;
  bool _working = false;

  bool _can(String permission) => widget.isSuperAdmin || widget.permissions[permission] == true;

  @override
  void initState() {
    super.initState();
    if (!_can('approveUsers')) {
      _tab = _can('manageUsers') ? 1 : (_can('manageRooms') ? 2 : (_can('viewAuditLogs') ? 4 : 3));
    }
  }

  Future<void> _run(Future<void> Function() action, String success) async {
    if (_working) return;
    setState(() => _working = true);
    try {
      await action();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(success)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Action failed: $e')));
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Admin Console', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            if (_working)
              const Padding(padding: EdgeInsets.all(16), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))
            else
              const Padding(padding: EdgeInsets.only(right: 16), child: Icon(Icons.shield_rounded, color: AkPlayApp.pink)),
          ],
        ),
        floatingActionButton: widget.isSuperAdmin && _tab == 3
            ? FloatingActionButton.extended(onPressed: _working ? null : _showAddModerator, icon: const Icon(Icons.person_add_alt_1), label: const Text('Add moderator'))
            : widget.isSuperAdmin && _tab == 5
                ? FloatingActionButton.extended(onPressed: _working ? null : _showGrantVip, icon: const Icon(Icons.workspace_premium), label: const Text('Grant VIP'))
                : null,
        body: Column(children: [
          _summary(),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              if (_can('approveUsers')) _tabButton('Pending', 0),
              if (_can('manageUsers')) _tabButton('Users', 1),
              if (_can('manageRooms')) _tabButton('Rooms', 2),
              if (widget.isSuperAdmin) _tabButton('Moderators', 3),
              if (widget.isSuperAdmin) _tabButton('VIP', 5),
              if (_can('viewAuditLogs')) _tabButton('Audit log', 4),
            ]),
          ),
          const Divider(color: Colors.white12, height: 1),
          Expanded(child: _content()),
        ]),
      );

  Future<void> _showAddModerator() async {
    final uidController = TextEditingController();
    final permissions = <String, bool>{
      'approveUsers': true,
      'manageUsers': true,
      'blockUsers': true,
      'manageRooms': true,
      'viewAuditLogs': false,
    };
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
        title: const Text('Appoint moderator'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Enter the email address or Firebase Auth UID of an existing AK PLAY account. The person must sign out and back in to refresh their permissions.', style: TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 12),
          TextField(controller: uidController, decoration: const InputDecoration(labelText: 'Account email or UID', prefixIcon: Icon(Icons.person_search))),
          const SizedBox(height: 12),
          ...permissions.keys.map((key) => SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(_permissionLabel(key), style: const TextStyle(fontSize: 13)),
            value: permissions[key]!,
            onChanged: (v) => setDialogState(() => permissions[key] = v),
          )),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(onPressed: () {
            final uid = uidController.text.trim();
            if (uid.isEmpty) return;
            Navigator.pop(dialogContext, {'identifier': uid, 'permissions': Map<String, bool>.from(permissions)});
          }, child: const Text('Appoint')),
        ],
      )),
    );
    uidController.dispose();
    if (result == null) return;
    await _run(() => _admin.setModerator(result['identifier'] as String, result['permissions'] as Map<String, bool>), 'Moderator appointed. They must sign in again.');
  }

  String _permissionLabel(String key) {
    switch (key) {
      case 'approveUsers': return 'Approve / reject registrations';
      case 'manageUsers': return 'View and manage users';
      case 'blockUsers': return 'Block / unblock users';
      case 'manageRooms': return 'Manage and close voice rooms';
      case 'viewAuditLogs': return 'View audit logs';
      default: return key;
    }
  }

  Widget _summary() => Container(
        margin: const EdgeInsets.fromLTRB(16, 8, 16, 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: const LinearGradient(colors: [Color(0xFF45235E), Color(0xFF24152F)]),
        ),
        child: Row(children: [
          const Icon(Icons.admin_panel_settings_rounded, size: 34, color: AkPlayApp.pink),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.isSuperAdmin ? 'Super Admin' : 'Moderator', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const Text('AK PLAY security and community controls', style: TextStyle(color: Colors.white70, fontSize: 12)),
          ])),
          const Icon(Icons.verified_user, color: Color(0xFF9BE7C4)),
        ]),
      );

  Widget _tabButton(String label, int value) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 5),
        child: ChoiceChip(label: Text(label), selected: _tab == value, onSelected: (_) => setState(() => _tab = value)),
      );

  Widget _content() {
    switch (_tab) {
      case 0: return _can('approveUsers') ? _pendingList() : _noPermission();
      case 1: return _can('manageUsers') ? _usersList() : _noPermission();
      case 2: return _can('manageRooms') ? _roomsList() : _noPermission();
      case 3: return widget.isSuperAdmin ? _moderatorsList() : _noPermission();
      case 4: return _can('viewAuditLogs') ? _auditList() : _noPermission();
      case 5: return widget.isSuperAdmin ? _vipList() : _noPermission();
      default: return const SizedBox.shrink();
    }
  }

  Widget _pendingList() => _queryList(
        _admin.pendingUsers(),
        empty: 'No registrations are waiting for approval.',
        builder: (doc) {
          final d = doc.data();
          return _personCard(doc.id, d, trailing: Wrap(spacing: 4, children: [
            IconButton(tooltip: 'Reject', onPressed: () => _run(() => _admin.rejectUser(doc.id), 'Registration rejected'), icon: const Icon(Icons.close, color: Colors.redAccent)),
            IconButton(tooltip: 'Approve', onPressed: () => _run(() => _admin.approveUser(doc.id), 'Account approved'), icon: const Icon(Icons.check_circle, color: Color(0xFF75D6A6))),
          ]));
        },
      );

  Widget _usersList() => _queryList(
        _admin.allUsers(),
        empty: 'No users found.',
        builder: (doc) {
          final d = doc.data();
          final blocked = d['blocked'] == true;
          final status = (d['approvalStatus'] ?? 'pending').toString();
          return _personCard(doc.id, d, subtitle: '$status${blocked ? ' • blocked' : ''}', trailing: _can('blockUsers') && (widget.isSuperAdmin || (d['role'] != 'moderator' && d['role'] != 'super_admin')) ? PopupMenuButton<String>(
            onSelected: (v) => _run(() => _admin.setBlocked(doc.id, v == 'block'), v == 'block' ? 'User blocked' : 'User unblocked'),
            itemBuilder: (_) => [
              PopupMenuItem(value: blocked ? 'unblock' : 'block', child: Text(blocked ? 'Unblock user' : 'Block user')),
            ],
          ) : null);
        },
      );

  Widget _roomsList() => _queryList(
        _admin.activeRooms(),
        empty: 'There are no active rooms.',
        builder: (doc) {
          final d = doc.data();
          return Card(color: const Color(0xFF21152F), child: ListTile(
            leading: Icon(d['isPrivate'] == true ? Icons.lock : Icons.mic, color: AkPlayApp.pink),
            title: Text((d['name'] ?? 'Untitled room').toString()),
            subtitle: Text(d['isPrivate'] == true ? 'Private room' : 'Public room'),
            trailing: IconButton(tooltip: 'Close room', icon: const Icon(Icons.stop_circle_outlined, color: Colors.redAccent), onPressed: () => _run(() => _admin.closeRoom(doc.id), 'Room closed')),
          ));
        },
      );

  Widget _auditList() => _queryList(
        _admin.auditLogs(),
        empty: 'No moderation actions have been recorded.',
        builder: (doc) {
          final d = doc.data();
          return Card(color: const Color(0xFF21152F), child: ListTile(
            leading: const Icon(Icons.history, color: AkPlayApp.pink),
            title: Text((d['action'] ?? 'Admin action').toString().replaceAll('_', ' ')),
            subtitle: Text('Actor: ${(d['actorUid'] ?? 'unknown')}\nTarget: ${(d['targetUid'] ?? 'unknown')}', maxLines: 2),
          ));
        },
      );

  Widget _moderatorsList() => _queryList(
        _admin.moderators(),
        empty: 'No moderators have been assigned.',
        builder: (doc) {
          final d = doc.data();
          return _personCard(doc.id, d, trailing: IconButton(
            tooltip: 'Remove moderator role', icon: const Icon(Icons.remove_moderator_outlined, color: Colors.orangeAccent),
            onPressed: () => _run(() => _admin.removeModerator(doc.id), 'Moderator role removed'),
          ));
        },
      );

  Future<void> _showGrantVip() async {
    final uid = TextEditingController();
    String tier = 'silver';
    final result = await showDialog<Map<String, dynamic>>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setStateDialog) => AlertDialog(
      title: const Text('Grant VIP membership'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Enter an existing AK PLAY user UID. This is an admin grant, not a store purchase.', style: TextStyle(color: Colors.white70, fontSize: 12)),
        const SizedBox(height: 12), TextField(controller: uid, decoration: const InputDecoration(labelText: 'User UID')),
        const SizedBox(height: 12), DropdownButtonFormField<String>(value: tier, items: const [DropdownMenuItem(value: 'silver', child: Text('Silver')), DropdownMenuItem(value: 'gold', child: Text('Gold')), DropdownMenuItem(value: 'diamond', child: Text('Diamond'))], onChanged: (v) => setStateDialog(() => tier = v ?? 'silver'), decoration: const InputDecoration(labelText: 'VIP tier')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, {'uid': uid.text.trim(), 'tier': tier}), child: const Text('Grant 30 days'))],
    )));
    uid.dispose();
    if (result == null || (result['uid'] as String).isEmpty) return;
    await _run(() async { await FirebaseFunctions.instance.httpsCallable('setVipEntitlement').call({'uid': result['uid'], 'tier': result['tier'], 'active': true, 'days': 30}); }, 'VIP membership granted for 30 days.');
  }

  Widget _vipList() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance.collection('vipSubscriptions').orderBy('updatedAt', descending: true).limit(100).snapshots(),
    builder: (context, snapshot) {
      if (snapshot.hasError) return Center(child: Text('Could not load VIP memberships: ${snapshot.error}'));
      if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
      final docs = snapshot.data!.docs;
      if (docs.isEmpty) return const Center(child: Text('No VIP memberships yet. Use Grant VIP to assign a test or promotional membership.'));
      return ListView.separated(padding: const EdgeInsets.all(14), itemCount: docs.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) {
        final doc = docs[i]; final d = doc.data();
        final expires = d['expiresAt'] is Timestamp ? (d['expiresAt'] as Timestamp).toDate().toLocal().toString() : 'Not available';
        return Card(color: const Color(0xFF21152F), child: ListTile(
          leading: const Icon(Icons.workspace_premium, color: Color(0xFFFFD66B)),
          title: Text('${(d['tier'] ?? 'VIP').toString().toUpperCase()} • ${(d['status'] ?? 'unknown')}'),
          subtitle: Text('UID: ${doc.id}\nExpires: $expires', maxLines: 2),
          trailing: (d['status'] == 'active') ? IconButton(icon: const Icon(Icons.block, color: Colors.redAccent), tooltip: 'Revoke VIP', onPressed: () => _run(() async { await FirebaseFunctions.instance.httpsCallable('setVipEntitlement').call({'uid': doc.id, 'tier': d['tier'] ?? 'silver', 'active': false}); }, 'VIP membership revoked.')) : null,
        ));
      });
    },
  );

  Widget _noPermission() => const Center(child: Text('Your moderator role does not include this permission.', style: TextStyle(color: Colors.white60)));

  Widget _queryList(Stream<QuerySnapshot<Map<String, dynamic>>> stream, {required String empty, required Widget Function(QueryDocumentSnapshot<Map<String, dynamic>>) builder}) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Could not load data. Check admin permissions and Firestore indexes.\n${snapshot.error}', textAlign: TextAlign.center)));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(empty, style: const TextStyle(color: Colors.white60))));
          return ListView.separated(padding: const EdgeInsets.all(14), itemCount: docs.length, separatorBuilder: (_, __) => const SizedBox(height: 7), itemBuilder: (_, i) => builder(docs[i]));
        },
      );

  Widget _personCard(String uid, Map<String, dynamic> d, {String? subtitle, Widget? trailing}) => Card(
        color: const Color(0xFF21152F),
        child: ListTile(
          leading: CircleAvatar(backgroundColor: const Color(0xFF48275E), child: Text(((d['displayName'] ?? 'U').toString().isNotEmpty ? (d['displayName'] ?? 'U').toString()[0] : 'U').toUpperCase(), style: const TextStyle(color: AkPlayApp.pink))),
          title: Text((d['displayName'] ?? 'Unnamed user').toString()),
          subtitle: Text(subtitle ?? (d['email'] ?? uid).toString(), maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: trailing,
        ),
      );
}
