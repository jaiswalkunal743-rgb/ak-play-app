import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../main.dart';

class MusicScreen extends StatefulWidget { const MusicScreen({super.key}); @override State<MusicScreen> createState()=>_MusicScreenState(); }
class _MusicScreenState extends State<MusicScreen> {
 final player=AudioPlayer(); bool playing=false;
 @override void dispose(){player.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Music Corner',style:TextStyle(fontWeight:FontWeight.bold))),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[Container(width:210,height:210,decoration:BoxDecoration(borderRadius:BorderRadius.circular(32),gradient:const LinearGradient(colors:[Color(0xFF743B9B),Color(0xFFEB70B9)]),boxShadow:[BoxShadow(color:AkPlayApp.pink.withOpacity(.18),blurRadius:35)]),child:const Icon(Icons.music_note_rounded,size:100,color:Colors.white)),const SizedBox(height:24),const Text('Your soundtrack',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('Add licensed audio or your own music files to start listening.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white70)),const SizedBox(height:22),FilledButton.icon(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Connect an audio source in the project setup to play music.'))),icon:Icon(playing?Icons.pause:Icons.play_arrow),label:const Text('Play music'))]))));
}
