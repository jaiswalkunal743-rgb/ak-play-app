import 'package:flutter/material.dart';
import '../main.dart';
import '../services/voice_room_service.dart';

class RoomsScreen extends StatefulWidget { const RoomsScreen({super.key}); @override State<RoomsScreen> createState()=>_RoomsScreenState(); }
class _RoomsScreenState extends State<RoomsScreen> {
  final service = VoiceRoomService();
  final rooms = const [
    _Room('Late Night Talks', 'Public', '12 listening', Icons.nightlight_round),
    _Room('Music & Chill', 'Public', '8 listening', Icons.queue_music),
    _Room('Our Circle', 'Private', 'Invite only', Icons.lock_outline),
  ];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Voice Rooms', style: TextStyle(fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: _createRoom, icon: const Icon(Icons.add_circle_outline, color: AkPlayApp.pink))]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Find your people and join the conversation.', style: TextStyle(color: Colors.white70)), const SizedBox(height: 18),
      ...rooms.map((r)=>Card(color: const Color(0xFF21152F), child: ListTile(leading: CircleAvatar(backgroundColor: AkPlayApp.purple.withOpacity(.2), child: Icon(r.icon, color: AkPlayApp.pink)), title: Text(r.name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${r.type} • ${r.info}'), trailing: FilledButton(onPressed: ()=>_join(r), child: const Text('Join'))))),
      const SizedBox(height: 12), const Text('Private rooms require an invitation code. Live audio requires Agora configuration.', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );
  Future<void> _join(_Room r) async { if(r.type=='Private') { final c=TextEditingController(); final code=await showDialog<String>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Private room'),content:TextField(controller:c,decoration:const InputDecoration(hintText:'Invitation code')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,c.text),child:const Text('Continue'))])); if(code==null||code.trim().isEmpty)return; }
    if(!mounted)return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Room selected: ${r.name}. Configure Agora to enable live audio.')));
  }
  Future<void> _createRoom() async { final name=TextEditingController(); String type='Public'; final result=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(title:const Text('Create a room'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(hintText:'Room name')),const SizedBox(height:12),DropdownButtonFormField<String>(value:type,items:const [DropdownMenuItem(value:'Public',child:Text('Public')),DropdownMenuItem(value:'Private',child:Text('Private'))],onChanged:(v)=>setD(()=>type=v??'Public'))]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Create'))]))); if(result==true&&name.text.trim().isNotEmpty&&mounted){await service.createRoom(name:name.text.trim(),isPrivate:type=='Private'); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Room creation request sent.')));} }
}
class _Room { final String name,type,info; final IconData icon; const _Room(this.name,this.type,this.info,this.icon); }
