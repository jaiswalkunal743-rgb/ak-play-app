import 'package:flutter/material.dart';
import '../main.dart';

class SetupRequiredScreen extends StatelessWidget {
  const SetupRequiredScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(
      mainAxisSize: MainAxisSize.min, children: [
        Image.asset('assets/ak_play_logo.png', width: 190, height: 190, fit: BoxFit.contain),
        const SizedBox(height: 18), const Text('AK PLAY', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 3)),
        const SizedBox(height: 12), const Text('Your app UI is ready. Connect Firebase to enable sign-in, user approval, photo uploads and cloud rooms.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, height: 1.5)),
        const SizedBox(height: 20), const Text('See README.md for setup instructions.', style: TextStyle(color: AkPlayApp.pink)),
      ],
    ))),
  );
}
