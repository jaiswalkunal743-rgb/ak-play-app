import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../main.dart';
import '../services/auth_service.dart';
import 'admin_dashboard_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, this.isStaff = false, this.isSuperAdmin = false, this.staffPermissions = const {}});
  final bool isStaff;
  final bool isSuperAdmin;
  final Map<String, dynamic> staffPermissions;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Profile', style: TextStyle(fontWeight: FontWeight.bold))),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const SizedBox(height: 16),
      const Center(child: CircleAvatar(radius: 48, backgroundColor: Color(0xFF48275E), child: Icon(Icons.person, size: 52, color: AkPlayApp.pink))),
      const SizedBox(height: 14),
      const Center(child: Text('Your AK PLAY profile', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      const Center(child: Text('Connect, listen, share and talk', style: TextStyle(color: Colors.white60))),
      const SizedBox(height: 12),
      _vipBadge(),
      const SizedBox(height: 28),
      _item(Icons.verified_user_outlined, 'Account status', 'Approved account'),
      _item(Icons.photo_outlined, 'My photos', 'Manage your memories'),
      _item(Icons.notifications_outlined, 'Notifications', 'Community updates'),
      _item(Icons.settings_outlined, 'Settings', 'Privacy and preferences'),
      if (isStaff) ...[
        const SizedBox(height: 12),
        Card(color: const Color(0xFF352044), child: ListTile(
          leading: const Icon(Icons.admin_panel_settings, color: AkPlayApp.pink),
          title: const Text('Admin Console', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(isSuperAdmin ? 'Super Admin • Full access' : 'Moderator • Assigned permissions'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AdminDashboardScreen(isSuperAdmin: isSuperAdmin, permissions: staffPermissions))),
        )),
      ],
      const SizedBox(height: 18),
      FilledButton.tonalIcon(onPressed: () => AuthService().signOut(), icon: const Icon(Icons.logout), label: const Text('Sign out')),
      const SizedBox(height: 18),
      const Text('AK PLAY • Connect, listen, share and talk', textAlign: TextAlign.center, style: TextStyle(color: AkPlayApp.pink)),
    ]),
  );

  static Widget _vipBadge() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const SizedBox.shrink();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('vipSubscriptions').doc(uid).snapshots(),
      builder: (context, snapshot) {
        final data = snapshot.data?.data();
        final expiry = data?['expiresAt'];
        final active = data?['status'] == 'active' && expiry is Timestamp && expiry.toDate().isAfter(DateTime.now());
        if (!active) return const SizedBox.shrink();
        final tier = (data?['tier'] ?? 'vip').toString().toUpperCase();
        return Center(child: Chip(avatar: const Icon(Icons.workspace_premium, color: Color(0xFFFFD66B)), label: Text('$tier VIP MEMBER'), backgroundColor: const Color(0xFF382344)));
      },
    );
  }

  static Widget _item(IconData i, String t, String s) => Card(color: const Color(0xFF21152F), child: ListTile(leading: Icon(i, color: AkPlayApp.pink), title: Text(t), subtitle: Text(s), trailing: const Icon(Icons.chevron_right)));
}
