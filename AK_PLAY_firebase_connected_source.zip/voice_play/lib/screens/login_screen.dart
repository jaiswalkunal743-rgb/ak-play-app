import 'package:flutter/material.dart';
import '../main.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState()=>_LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen> {
 final form=GlobalKey<FormState>(); final name=TextEditingController(); final email=TextEditingController(); final password=TextEditingController(); bool register=false; bool busy=false;
 @override void dispose(){name.dispose();email.dispose();password.dispose();super.dispose();}
 Future<void> submit() async { if(!form.currentState!.validate())return; setState(()=>busy=true); try { if(register){await AuthService().register(name:name.text,email:email.text,password:password.text);}else{await AuthService().signIn(email:email.text,password:password.text);} } catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));} finally{if(mounted)setState(()=>busy=false);} }
 @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Form(key:form,child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
 const SizedBox(height:24),Image.asset('assets/ak_play_logo.png', width: 190, height: 190, fit: BoxFit.contain),const SizedBox(height:12),const Center(child:Text('AK PLAY',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,letterSpacing:3))),const SizedBox(height:8),Center(child:Text(register?'Create your account':'Welcome back',style:const TextStyle(color:Colors.white70))),const SizedBox(height:32),
 if(register)...[TextFormField(controller:name,decoration:const InputDecoration(labelText:'Your name',prefixIcon:Icon(Icons.person_outline)),validator:(v)=>v==null||v.trim().isEmpty?'Enter your name':null),const SizedBox(height:14)],
 TextFormField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email address',prefixIcon:Icon(Icons.email_outlined)),validator:(v)=>v==null||!v.contains('@')?'Enter a valid email':null),const SizedBox(height:14),
 TextFormField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password',prefixIcon:Icon(Icons.lock_outline)),validator:(v)=>v==null||v.length<6?'Use at least 6 characters':null),const SizedBox(height:22),
 FilledButton(onPressed:busy?null:submit,style:FilledButton.styleFrom(padding:const EdgeInsets.symmetric(vertical:16)),child:busy?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):Text(register?'Create account':'Log in')),
 TextButton(onPressed:busy?null:()=>setState(()=>register=!register),child:Text(register?'Already have an account? Log in':'New to AK PLAY? Create account')),
 if(register)const Text('New accounts require admin approval before app access.',textAlign:TextAlign.center,style:TextStyle(color:AkPlayApp.pink,fontSize:12)),
 ]))))));
}
