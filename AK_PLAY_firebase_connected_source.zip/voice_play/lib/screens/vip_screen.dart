import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../main.dart';
import '../services/vip_service.dart';

class VipScreen extends StatefulWidget {
  const VipScreen({super.key});
  @override State<VipScreen> createState() => _VipScreenState();
}
class _VipScreenState extends State<VipScreen> {
  final _vip = VipService();
  StreamSubscription<List<PurchaseDetails>>? _purchaseSub;
  List<ProductDetails> _products = [];
  bool _loading = true;
  String? _message;

  @override void initState() { super.initState(); _initStore(); }
  Future<void> _initStore() async {
    try {
      _products = await _vip.loadProducts();
      _purchaseSub = _vip.store.purchaseStream.listen(_onPurchases, onError: (e) { if (mounted) setState(() => _message = 'Store error: $e'); });
    } catch (e) { _message = 'Store setup required: $e'; }
    if (mounted) setState(() => _loading = false);
  }
  Future<void> _onPurchases(List<PurchaseDetails> purchases) async {
    for (final p in purchases) {
      if (p.status == PurchaseStatus.purchased || p.status == PurchaseStatus.restored) {
        try {
          await _vip.submitPurchaseForVerification(p);
          if (mounted) setState(() => _message = 'VIP membership verified and activated.');
        } catch (e) {
          if (mounted) setState(() => _message = 'Purchase received but not activated: server-side store verification must be configured.');
        }
      } else if (p.status == PurchaseStatus.error) {
        if (mounted) setState(() => _message = p.error?.message ?? 'Purchase failed.');
      }
      if (p.pendingCompletePurchase && (p.status == PurchaseStatus.error || p.status == PurchaseStatus.canceled)) {
        await _vip.store.completePurchase(p);
      }
    }
  }
  @override void dispose() { _purchaseSub?.cancel(); super.dispose(); }

  @override Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(appBar: AppBar(title: const Text('AK PLAY VIP 👑')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF5B2C78), Color(0xFF21132F)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('UNLOCK YOUR VIP EXPERIENCE', style: TextStyle(letterSpacing: 1.4, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('Stand out in every room.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)), SizedBox(height: 5), Text('Exclusive badges • Frames • Gifts • Effects', style: TextStyle(color: Colors.white70))])),
        const SizedBox(height: 14),
        if (uid != null) StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(stream: FirebaseFirestore.instance.collection('vipSubscriptions').doc(uid).snapshots(), builder: (context,s) { final d=s.data?.data(); final active=d?['status']=='active' && (d?['expiresAt'] is Timestamp) && (d!['expiresAt'] as Timestamp).toDate().isAfter(DateTime.now()); return Card(color: AkPlayApp.panel, child: ListTile(leading: const Icon(Icons.verified, color: Color(0xFFFFD66B)), title: Text(active ? '${(d?['tier'] ?? 'VIP').toString().toUpperCase()} MEMBER' : 'No active membership'), subtitle: Text(active ? 'Expires ${((d?['expiresAt'] as Timestamp).toDate()).toLocal()}' : 'Choose a plan below'))); }),
        if (_message != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_message!, style: const TextStyle(color: Colors.white70))),
        for (final tier in vipTiers) _tierCard(tier),
        if (_loading) const Center(child: CircularProgressIndicator()),
        OutlinedButton.icon(onPressed: () async { try { await _vip.store.restorePurchases(); } catch (e) { if (mounted) setState(() => _message = 'Restore failed: $e'); } }, icon: const Icon(Icons.restore), label: const Text('Restore purchases')),
        const Padding(padding: EdgeInsets.only(top: 12), child: Text('Subscriptions are billed by Google Play or Apple App Store. Membership activation requires secure server-side purchase verification and configured store products.', style: TextStyle(color: Colors.white54, fontSize: 12))),
      ]));
  }
  Widget _tierCard(VipTier tier) {
    final matches = _products.where((p) => p.id == tier.productId);
    final product = matches.isEmpty ? null : matches.first;
    return Card(color: const Color(0xFF21152F), margin: const EdgeInsets.only(bottom: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: tier.id=='diamond' ? const Color(0xFFD5A6FF) : AkPlayApp.purple.withOpacity(.35))), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Text(tier.badge, style: const TextStyle(fontSize: 30)), const SizedBox(width: 10), Expanded(child: Text(tier.name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold))), Text(product?.price ?? tier.price, style: const TextStyle(color: Color(0xFFFFD66B), fontWeight: FontWeight.bold))]),
      const SizedBox(height: 10), for (final benefit in tier.benefits) Padding(padding: const EdgeInsets.only(bottom: 5), child: Row(children: [const Icon(Icons.check_circle, size: 16, color: Color(0xFF9BE7C4)), const SizedBox(width: 8), Expanded(child: Text(benefit))])),
      const SizedBox(height: 10), SizedBox(width: double.infinity, child: FilledButton(onPressed: product == null ? null : () async { try { await _vip.buy(product); } catch(e) { if(mounted) setState(()=>_message='Could not start purchase: $e'); } }, child: Text(product == null ? 'Store product not configured' : 'Subscribe ${product.price}'))),
    ])));
  }
}
