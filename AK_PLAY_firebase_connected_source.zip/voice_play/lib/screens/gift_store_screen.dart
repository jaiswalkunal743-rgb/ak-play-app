import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../main.dart';
import '../services/gift_service.dart';

class GiftStoreScreen extends StatefulWidget {
  const GiftStoreScreen({super.key});
  @override State<GiftStoreScreen> createState() => _GiftStoreScreenState();
}

class _GiftStoreScreenState extends State<GiftStoreScreen> {
  final service = GiftService();
  final roomId = TextEditingController();
  final receiver = TextEditingController();
  String? activeRoom;
  String? lastEventId;
  String? animationEmoji;
  String? animationText;

  @override void dispose() { roomId.dispose(); receiver.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Gift Store 🎁')),
      body: Stack(children: [
        ListView(padding: const EdgeInsets.all(16), children: [
          Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: const LinearGradient(colors: [Color(0xFF51246D), Color(0xFF24142F)])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('AK PLAY COINS', style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
            if (uid != null) StreamBuilder(stream: service.watchWallet(uid), builder: (context, snap) { final coins = snap.data?.data()?['balance'] ?? 0; return Text('$coins 🪙', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: Color(0xFFFFD66B))); }) else const Text('Sign in to view your wallet'),
            const Text('Purchase packages will be activated after store billing setup.', style: TextStyle(color: Colors.white70, fontSize: 11)),
          ])),
          const SizedBox(height: 18),
          const Text('Send a gift in a voice room', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 10),
          TextField(controller: roomId, decoration: const InputDecoration(labelText: 'Voice room ID', hintText: 'Enter the active room ID')),
          const SizedBox(height: 8), TextField(controller: receiver, decoration: const InputDecoration(labelText: 'Receiver user ID', hintText: 'Enter recipient UID')),
          const SizedBox(height: 18),
          const Text('Romantic Gifts', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 10),
          _giftGrid(giftCatalog.take(6).toList()), const SizedBox(height: 18),
          const Text('Premium & Special Gifts', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 10),
          _giftGrid(giftCatalog.skip(6).toList()), const SizedBox(height: 22),
          const Text('🏆 Top Gift Receivers', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 8),
          StreamBuilder(stream: service.watchLeaderboard(), builder: (context, snap) {
            if (snap.hasError) return const Text('Leaderboard will appear after the first gift.');
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs;
            if (docs.isEmpty) return const Text('No gifts received yet. Be the first!');
            return Column(children: [for (var i = 0; i < docs.length; i++) ListTile(leading: CircleAvatar(backgroundColor: AkPlayApp.purple.withOpacity(.25), child: Text('${i + 1}')), title: Text(docs[i].data()['displayName'] ?? 'AK PLAY user'), trailing: Text('${docs[i].data()['totalReceived'] ?? 0} 🪙', style: const TextStyle(color: Color(0xFFFFD66B), fontWeight: FontWeight.bold))) ]);
          }),
          const SizedBox(height: 12),
          const Text('Gift animations appear to everyone currently viewing the same active room. Enter its real room ID above.', style: TextStyle(color: Colors.white54, fontSize: 12)),
        ]),
        if (roomId.text.trim().isNotEmpty) _roomAnimationListener(roomId.text.trim()),
        if (animationEmoji != null) Positioned.fill(child: GestureDetector(onTap: () => setState(() { animationEmoji = null; animationText = null; }), child: Container(color: Colors.black.withOpacity(.88), child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text(animationEmoji!, style: const TextStyle(fontSize: 100)), const SizedBox(height: 18), Text(animationText ?? 'A gift was sent!', textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 12), const Text('Tap to close', style: TextStyle(color: Colors.white70))]))))),
      ]),
    );
  }

  Widget _giftGrid(List<GiftItem> gifts) => GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: gifts.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: .95, crossAxisSpacing: 10, mainAxisSpacing: 10), itemBuilder: (context, i) {
    final gift = gifts[i];
    return InkWell(onTap: () => _send(gift), borderRadius: BorderRadius.circular(16), child: Container(decoration: BoxDecoration(color: AkPlayApp.panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: AkPlayApp.purple.withOpacity(.3))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(gift.emoji, style: const TextStyle(fontSize: 34)), const SizedBox(height: 5), Text(gift.name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)), const SizedBox(height: 3), Text('${gift.coins} 🪙', style: const TextStyle(color: Color(0xFFFFD66B), fontSize: 11))])));
  });

  Future<void> _send(GiftItem gift) async {
    final rid = roomId.text.trim(), to = receiver.text.trim();
    if (rid.isEmpty || to.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter the active room ID and receiver user ID first.'))); return; }
    try { await service.sendGift(roomId: rid, receiverUid: to, giftId: gift.id); if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${gift.name} sent successfully!'))); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gift could not be sent: $e'))); }
  }

  Widget _roomAnimationListener(String rid) => StreamBuilder(stream: service.watchRoomGifts(rid), builder: (context, snap) {
    if (!snap.hasData || snap.data!.docs.isEmpty) return const SizedBox.shrink();
    final doc = snap.data!.docs.first;
    if (lastEventId != doc.id) {
      lastEventId = doc.id;
      WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) setState(() { animationEmoji = doc.data()['emoji'] ?? '🎁'; animationText = '${doc.data()['senderName'] ?? 'Someone'} sent ${doc.data()['giftName'] ?? 'a gift'} to ${doc.data()['receiverName'] ?? 'a user'}!'; }); });
    }
    return const SizedBox.shrink();
  });
}
