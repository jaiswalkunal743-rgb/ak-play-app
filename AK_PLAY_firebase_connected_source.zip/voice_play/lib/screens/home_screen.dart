import 'package:flutter/material.dart';
import '../widgets/gradient_header.dart';
import '../main.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Row(children: [CircleAvatar(backgroundColor: Color(0xFF3B2450), child: Icon(Icons.favorite, color: AkPlayApp.pink)), SizedBox(width: 12), Expanded(child: Text('Welcome to your space', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))), Icon(Icons.notifications_none)]),
    const SizedBox(height: 20), const GradientHeader(title: 'Every voice has a story.', subtitle: 'Meet, listen, share and make memories.'),
    const SizedBox(height: 22), const Text('Explore AK PLAY', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    _tile(Icons.mic, 'Live voice rooms', 'Join public conversations or enter a private room.'),
    _tile(Icons.photo_camera_back, 'Moments & memories', 'Keep your favorite photos together.'),
    _tile(Icons.headphones, 'Music corner', 'Enjoy your playlists and favorite sounds.'),
    const SizedBox(height: 10), const Center(child: Text('Made with ♥', style: TextStyle(color: AkPlayApp.pink, letterSpacing: 2))),
  ]);
  static Widget _tile(IconData icon, String title, String sub) => Card(color: const Color(0xFF21152F), child: ListTile(leading: CircleAvatar(backgroundColor: AkPlayApp.purple.withOpacity(.2), child: Icon(icon, color: AkPlayApp.pink)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(sub)));
}
