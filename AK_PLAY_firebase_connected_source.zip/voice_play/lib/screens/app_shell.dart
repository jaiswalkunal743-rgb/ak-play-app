import 'package:flutter/material.dart';
import '../main.dart';
import 'home_screen.dart';
import 'rooms_screen.dart';
import 'gallery_screen.dart';
import 'music_screen.dart';
import 'profile_screen.dart';
import 'gift_store_screen.dart';
import 'vip_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key, this.isStaff = false, this.isSuperAdmin = false, this.staffPermissions = const {}});
  final bool isStaff;
  final bool isSuperAdmin;
  final Map<String, dynamic> staffPermissions;
  @override State<AppShell> createState() => _AppShellState();
}
class _AppShellState extends State<AppShell> {
  int index = 0;
  @override Widget build(BuildContext context) {
    final pages = [const HomeScreen(), const RoomsScreen(), const GiftStoreScreen(), const VipScreen(), const GalleryScreen(), const MusicScreen(), ProfileScreen(isStaff: widget.isStaff, isSuperAdmin: widget.isSuperAdmin, staffPermissions: widget.staffPermissions)];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF1A1025), indicatorColor: AkPlayApp.pink.withOpacity(.18),
        selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.mic_none), selectedIcon: Icon(Icons.mic), label: 'Rooms'),
          NavigationDestination(icon: Icon(Icons.card_giftcard_outlined), selectedIcon: Icon(Icons.card_giftcard), label: 'Gifts'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium), label: 'VIP'),
          NavigationDestination(icon: Icon(Icons.photo_library_outlined), selectedIcon: Icon(Icons.photo_library), label: 'Gallery'),
          NavigationDestination(icon: Icon(Icons.music_note_outlined), selectedIcon: Icon(Icons.music_note), label: 'Music'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
