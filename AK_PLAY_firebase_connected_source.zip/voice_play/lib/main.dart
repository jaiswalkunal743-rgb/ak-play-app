import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_performance/firebase_performance.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/auth_gate.dart';
import 'screens/setup_required_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  var firebaseReady = false;
  try {
    await Firebase.initializeApp();
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
    PlatformDispatcher.instance.onError = (error, stack) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      return true;
    };
    await FirebaseAnalytics.instance.logAppOpen();
    await FirebasePerformance.instance.setPerformanceCollectionEnabled(true);
    firebaseReady = true;
  } catch (_) {
    // The UI can run in preview mode until Firebase is configured.
  }
  runApp(AkPlayApp(firebaseReady: firebaseReady));
}

class AkPlayApp extends StatelessWidget {
  const AkPlayApp({super.key, required this.firebaseReady});
  final bool firebaseReady;

  static const bg = Color(0xFF100B1B);
  static const panel = Color(0xFF21152F);
  static const pink = Color(0xFFFF72C6);
  static const purple = Color(0xFF9A72FF);

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'AK PLAY',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: pink, secondary: purple, surface: panel),
      useMaterial3: true,
      appBarTheme: const AppBarTheme(backgroundColor: bg, elevation: 0),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white12)),
      ),
    ),
    home: firebaseReady ? const AuthGate() : const SetupRequiredScreen(),
  );
}
