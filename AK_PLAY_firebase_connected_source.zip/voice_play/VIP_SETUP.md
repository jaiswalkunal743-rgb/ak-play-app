# Voice Play VIP setup

## Subscription products
Create these auto-renewable monthly subscription products in both Google Play Console and App Store Connect. Use the same IDs in both stores:

- `voice_play_vip_silver_monthly` — proposed ₹99/month
- `voice_play_vip_gold_monthly` — proposed ₹199/month
- `voice_play_vip_diamond_monthly` — proposed ₹499/month

Prices shown in the app are fallback display values. The actual localized store price is displayed when the product is returned by the store.

## Flutter setup

1. Run `flutter pub get`.
2. Configure the Android application ID and iOS bundle ID to match the store apps.
3. Configure the subscription products in each store and test with license testers / sandbox testers.
4. Add the required store metadata, tax, banking, privacy policy, and subscription disclosures.
5. Test purchase, pending, cancellation, restore, renewal, grace period, refund and revocation paths.

## Critical backend work before accepting real payments

The Flutter client sends purchase verification data to the `verifyVipPurchase` callable. That callable intentionally fails closed until server-side verification is configured. Do not remove this guard or grant paid entitlements based on client-side purchase status.

Implement and configure:

- Google Play Developer API verification of purchase tokens, package name, product ID, purchase state and expiry; configure service-account credentials with Secret Manager.
- Apple App Store Server API / signed transaction JWS verification, bundle ID, product ID, environment, expiry and revocation; configure issuer ID, key ID and private key with Secret Manager.
- Deduplication by store transaction ID / purchase token, server notifications (Google RTDN and App Store Server Notifications V2), refunds, renewals, grace periods and billing retry handling.
- Store verified transactions in `vipPurchaseRecords` and grant/update `vipSubscriptions/{uid}` only from the trusted backend.

## Admin

The Super Admin can grant a promotional/manual 30-day VIP tier and revoke memberships from Admin Console → VIP. Moderators cannot grant or revoke VIP. All admin grants/revocations are written to the admin audit log.

## Security

`vipSubscriptions` is read-only to clients (owner and Super Admin can read); writes are denied in Firestore rules. Membership expiry is processed hourly by `expireVipMemberships`. VIP status is not a cash balance and cannot be redeemed for money.

## Current implementation boundary

The app UI, product IDs, purchase-stream listener, restore-purchases action, profile VIP badge, admin grant/revoke controls, server-owned entitlement callable, Firestore rules and expiry job are included. Actual store verification is **not yet enabled** until the provider API credentials and verification logic above are configured. A Flutter build was not run in this environment because Flutter/Dart SDKs are unavailable.
