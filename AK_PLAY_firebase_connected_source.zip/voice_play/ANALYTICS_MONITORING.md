# AK PLAY Analytics & Monitoring

Included Flutter SDKs: `firebase_analytics`, `firebase_crashlytics`, and `firebase_performance`. Startup records app opens, captures fatal Flutter/platform errors, and enables performance collection after Firebase initializes.

## Recommended privacy-safe events
- `registration_submitted`, `registration_approved`
- `voice_room_created`, `voice_room_joined`, `voice_room_left`
- `gift_sent` (gift ID and coin value only)
- `vip_purchase_started`, `vip_purchase_verified` (only after server verification)
- `moderation_action` (action category, not message contents)

Never log phone numbers, OTPs, passwords, UPI PINs, payment tokens, private messages, or precise location.

## Alerts to configure in Firebase / Google Cloud
- Crashlytics new fatal issues and regressions
- Cloud Functions error count, p95 latency, and invocation spikes
- Firestore read/write usage and quota/billing thresholds
- Authentication failures and App Check rejections
- Cloud Billing budget alerts

This file is a setup checklist; alert policies and dashboard resources must be created in the owner's Google Cloud project.
